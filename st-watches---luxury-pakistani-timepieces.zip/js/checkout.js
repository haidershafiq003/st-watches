/**
 * ST WATCHES - Checkout & WhatsApp Order Engine
 * Handles Pakistani Delivery Addresses, Form Validation, Order Itemization,
 * and Direct WhatsApp Order String Generation
 */

document.addEventListener('DOMContentLoaded', () => {
  initCheckout();
});

function initCheckout() {
  const cart = getCart();

  if (!cart || cart.length === 0) {
    const checkoutContainer = document.getElementById('checkout-page-container');
    if (checkoutContainer) {
      checkoutContainer.innerHTML = `
        <div style="text-align: center; padding: 4rem 1.25rem; background: #FFFFFF; border: 1px solid #E5E3DC; border-radius: 6px; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.04); max-width: 520px; margin: 0 auto; box-sizing: border-box;">
          <div style="width: 56px; height: 56px; border-radius: 50%; background: rgba(201, 162, 39, 0.1); display: flex; align-items: center; justify-content: center; margin: 0 auto 1.25rem;">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#C9A227" stroke-width="1.8"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 14 14"></polyline></svg>
          </div>
          <h2 style="font-family: var(--font-serif); font-size: 1.65rem; margin-bottom: 0.5rem; color: #0B0B0B;">Your Cart is Empty</h2>
          <p style="color: #65635C; margin-bottom: 1.5rem; font-size: 0.9rem; line-height: 1.5;">Please select at least one luxury timepiece before proceeding to express checkout.</p>
          <a href="shop.html" class="btn btn-gold" style="min-height: 48px; display: inline-flex; align-items: center; justify-content: center; padding: 0.75rem 1.75rem;">Explore Watch Collection</a>
        </div>
      `;
    }
    return;
  }

  // Setup Mobile Summary Accordion Toggle
  setupMobileSummaryToggle();

  renderCheckoutSummary(cart);

  // Restore saved customer data from localStorage if available
  restoreSavedCustomerData();

  // Setup Form Handlers
  setupOrderButtons(cart);
}

function setupMobileSummaryToggle() {
  const toggleBtn = document.getElementById('mobile-summary-toggle-btn');
  const collapsible = document.getElementById('mobile-summary-collapsible');
  const toggleText = document.getElementById('mobile-toggle-text');

  if (toggleBtn && collapsible) {
    toggleBtn.addEventListener('click', (e) => {
      e.preventDefault();
      const isExpanded = toggleBtn.classList.toggle('expanded');
      collapsible.classList.toggle('open');
      toggleBtn.setAttribute('aria-expanded', isExpanded ? 'true' : 'false');
      if (toggleText) {
        toggleText.textContent = isExpanded ? 'Hide order summary' : 'Show order summary';
      }
    });
  }
}

function renderCheckoutSummary(cart) {
  const itemsList = document.getElementById('checkout-items-list');
  const subtotalEl = document.getElementById('checkout-subtotal');
  const deliveryEl = document.getElementById('checkout-delivery');
  const totalEl = document.getElementById('checkout-total');

  // Mobile elements
  const mobileItemsList = document.getElementById('mobile-checkout-items-list');
  const mobileSubtotalEl = document.getElementById('mobile-checkout-subtotal');
  const mobileDeliveryEl = document.getElementById('mobile-checkout-delivery');
  const mobileTotalEl = document.getElementById('mobile-checkout-total');
  const mobileToggleTotalEl = document.getElementById('mobile-toggle-total');

  const subtotal = getCartSubtotal();
  const isFreeDelivery = subtotal >= ST_CONFIG.freeDeliveryThreshold;
  const delivery = isFreeDelivery ? 0 : ST_CONFIG.deliveryFee;
  const grandTotal = subtotal + delivery;

  const itemHtml = cart.map(item => `
    <div class="checkout-item-row">
      <div class="checkout-item-left">
        <img src="${item.image}" alt="${item.name}" class="checkout-item-thumb" />
        <div class="checkout-item-details">
          <div class="checkout-item-name">${item.name}</div>
          <div class="checkout-item-qty">Qty: ${item.quantity} × ${formatPKR(item.price)}</div>
        </div>
      </div>
      <div class="checkout-item-total">
        ${formatPKR(item.price * item.quantity)}
      </div>
    </div>
  `).join('');

  if (itemsList) itemsList.innerHTML = itemHtml;
  if (mobileItemsList) mobileItemsList.innerHTML = itemHtml;

  const formattedSubtotal = formatPKR(subtotal);
  const formattedDelivery = isFreeDelivery ? 'FREE (Complimentary)' : formatPKR(delivery);
  const formattedTotal = formatPKR(grandTotal);

  if (subtotalEl) subtotalEl.textContent = formattedSubtotal;
  if (deliveryEl) {
    deliveryEl.textContent = formattedDelivery;
    if (isFreeDelivery) deliveryEl.style.color = '#15803D';
  }
  if (totalEl) totalEl.textContent = formattedTotal;

  // Update mobile summary values
  if (mobileSubtotalEl) mobileSubtotalEl.textContent = formattedSubtotal;
  if (mobileDeliveryEl) {
    mobileDeliveryEl.textContent = formattedDelivery;
    if (isFreeDelivery) mobileDeliveryEl.style.color = '#15803D';
  }
  if (mobileTotalEl) mobileTotalEl.textContent = formattedTotal;
  if (mobileToggleTotalEl) mobileToggleTotalEl.textContent = formattedTotal;
}

function restoreSavedCustomerData() {
  try {
    const saved = localStorage.getItem('st_customer_info');
    if (saved) {
      const data = JSON.parse(saved);
      if (document.getElementById('cust-name') && data.name) document.getElementById('cust-name').value = data.name;
      if (document.getElementById('cust-phone') && data.phone) document.getElementById('cust-phone').value = data.phone;
      if (document.getElementById('cust-city') && data.city) document.getElementById('cust-city').value = data.city;
      if (document.getElementById('cust-address') && data.address) document.getElementById('cust-address').value = data.address;
    }
  } catch (e) {
    console.error(e);
  }
}

function saveCustomerData(data) {
  try {
    localStorage.setItem('st_customer_info', JSON.stringify(data));
  } catch (e) {
    console.error(e);
  }
}

function getFormData() {
  const name = document.getElementById('cust-name')?.value.trim();
  const phone = document.getElementById('cust-phone')?.value.trim();
  const city = document.getElementById('cust-city')?.value.trim();
  const address = document.getElementById('cust-address')?.value.trim();
  const notes = document.getElementById('cust-notes')?.value.trim() || 'None';

  if (!name) {
    showToast('Please enter your full name.', 'error');
    document.getElementById('cust-name')?.focus();
    return null;
  }

  if (!phone || phone.length < 10) {
    showToast('Please provide a valid Pakistani contact phone number.', 'error');
    document.getElementById('cust-phone')?.focus();
    return null;
  }

  if (!city) {
    showToast('Please select or specify your delivery city.', 'error');
    document.getElementById('cust-city')?.focus();
    return null;
  }

  if (!address || address.length < 10) {
    showToast('Please provide your complete street address for courier dispatch.', 'error');
    document.getElementById('cust-address')?.focus();
    return null;
  }

  const customerData = { name, phone, city, address, notes };
  saveCustomerData(customerData);
  return customerData;
}

function setupOrderButtons(cart) {
  const whatsappBtn = document.getElementById('btn-place-whatsapp-order');
  const codBtn = document.getElementById('btn-place-cod-order');

  if (whatsappBtn) {
    whatsappBtn.addEventListener('click', (e) => {
      e.preventDefault();
      handleWhatsAppOrder(cart);
    });
  }

  if (codBtn) {
    codBtn.addEventListener('click', (e) => {
      e.preventDefault();
      handleCodOrder(cart);
    });
  }
}

/**
 * Generates WhatsApp Order Message according to user requirements:
 * 
 * ST WATCHES — NEW ORDER
 * 
 * Customer Information:
 * Name:
 * Phone:
 * City:
 * Address:
 * Notes:
 * 
 * Order:
 * * Product name × quantity — price
 * 
 * Subtotal:
 * Delivery:
 * Total:
 */
function handleWhatsAppOrder(cart) {
  const customer = getFormData();
  if (!customer) return;

  const subtotal = getCartSubtotal();
  const isFreeDelivery = subtotal >= ST_CONFIG.freeDeliveryThreshold;
  const delivery = isFreeDelivery ? 0 : ST_CONFIG.deliveryFee;
  const total = subtotal + delivery;

  // Build itemized string
  const itemsText = cart.map(item => 
    `* ${item.name} × ${item.quantity} — ${formatPKR(item.price * item.quantity)}`
  ).join('\n');

  const deliveryStr = isFreeDelivery ? 'PKR 0 (Free Express)' : formatPKR(delivery);

  const message = 
`ST WATCHES — NEW ORDER

Customer Information:
Name: ${customer.name}
Phone: ${customer.phone}
City: ${customer.city}
Address: ${customer.address}
Notes: ${customer.notes}

Order:
${itemsText}

Subtotal: ${formatPKR(subtotal)}
Delivery: ${deliveryStr}
Total: ${formatPKR(total)}`;

  const encodedMessage = encodeURIComponent(message);
  const whatsappUrl = `https://wa.me/${ST_CONFIG.whatsappNumber}?text=${encodedMessage}`;

  // Record order locally
  const orderId = 'ST-' + Math.floor(100000 + Math.random() * 900000);
  saveOrderHistory({
    orderId,
    customer,
    cart,
    subtotal,
    delivery,
    total,
    method: 'WhatsApp Order',
    date: new Date().toISOString()
  });

  // Dispatch instant order notification email to owner inbox via FormSubmit
  sendOrderEmailViaFormSubmit(orderId, customer, cart, subtotal, delivery, total, 'WhatsApp Order (COD)');

  // Empty cart
  saveCart([]);
  window.dispatchEvent(new CustomEvent('st:cartUpdated', { detail: { cart: [] } }));

  // Display success confirmation modal with direct WhatsApp trigger
  showOrderSuccessModal(orderId, customer, cart, total, 'WhatsApp', whatsappUrl);

  // Navigate to WhatsApp after slight delay to ensure background fetch starts
  setTimeout(() => {
    try {
      window.location.href = whatsappUrl;
    } catch (e) {
      console.error(e);
    }
  }, 400);
}

function handleCodOrder(cart) {
  const customer = getFormData();
  if (!customer) return;

  const subtotal = getCartSubtotal();
  const isFreeDelivery = subtotal >= ST_CONFIG.freeDeliveryThreshold;
  const delivery = isFreeDelivery ? 0 : ST_CONFIG.deliveryFee;
  const total = subtotal + delivery;

  const orderId = 'ST-' + Math.floor(100000 + Math.random() * 900000);

  saveOrderHistory({
    orderId,
    customer,
    cart,
    subtotal,
    delivery,
    total,
    method: 'Cash on Delivery (COD)',
    date: new Date().toISOString()
  });

  // Dispatch instant order notification email to owner inbox via FormSubmit
  sendOrderEmailViaFormSubmit(orderId, customer, cart, subtotal, delivery, total, 'Cash on Delivery (COD)');

  // Clear cart
  saveCart([]);
  window.dispatchEvent(new CustomEvent('st:cartUpdated', { detail: { cart: [] } }));

  showOrderSuccessModal(orderId, customer, cart, total, 'COD');
}

/**
 * Sends order notification directly to store owner's inbox via FormSubmit AJAX API
 */
async function sendOrderEmailViaFormSubmit(orderId, customer, cart, subtotal, delivery, total, method) {
  const targetEmail = (typeof ST_CONFIG !== 'undefined' && ST_CONFIG.orderEmail)
    ? ST_CONFIG.orderEmail
    : 'haidershafiq03@gmail.com';

  const isFreeDelivery = delivery <= 0;
  const deliveryStr = isFreeDelivery ? 'FREE (Complimentary TCS Express)' : formatPKR(delivery);

  // Format timepiece items list for email table
  const watchesListFormatted = (cart && cart.length > 0)
    ? cart.map((item, idx) => `${idx + 1}. ${item.name} | Qty: ${item.quantity} | Unit: ${formatPKR(item.price)} | Subtotal: ${formatPKR(item.price * item.quantity)}`).join('\n')
    : 'Timepiece Order';

  const orderDateStr = new Date().toLocaleString('en-US', { timeZone: 'Asia/Karachi' }) + ' PKT';

  const payload = {
    _subject: `New ST Watches Order #${orderId} - ${customer.name} (${formatPKR(total)})`,
    _template: 'table',
    _captcha: 'false',
    'Order ID': `#${orderId}`,
    'Customer Name': customer.name,
    'Phone / WhatsApp (Courier Dial)': customer.phone,
    'Delivery City': customer.city,
    'Full Street Address': customer.address,
    'Courier Delivery Instructions': customer.notes || 'None',
    'Payment Method': method,
    'Ordered Timepieces': watchesListFormatted,
    'Subtotal': formatPKR(subtotal),
    'TCS Express Delivery': deliveryStr,
    'Grand Total Payable': formatPKR(total),
    'Order Placed At': orderDateStr
  };

  try {
    const res = await fetch(`https://formsubmit.co/ajax/${targetEmail}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify(payload)
    });
    const result = await res.json();
    console.log('FormSubmit notification response:', result);
    return result;
  } catch (err) {
    console.warn('FormSubmit background notification error:', err);
    return null;
  }
}

function saveOrderHistory(order) {
  try {
    const raw = localStorage.getItem('st_recent_orders');
    const orders = raw ? JSON.parse(raw) : [];
    orders.unshift(order);
    localStorage.setItem('st_recent_orders', JSON.stringify(orders.slice(0, 10)));
  } catch (e) {
    console.error(e);
  }
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function showOrderSuccessModal(orderId, customer, cart, total, type, whatsappUrl = '') {
  const existing = document.getElementById('order-success-modal');
  if (existing) existing.remove();

  const subtotal = (cart && cart.length > 0)
    ? cart.reduce((acc, item) => acc + (item.price * item.quantity), 0)
    : total;
  const delivery = Math.max(0, total - subtotal);
  const isFreeDelivery = delivery <= 0;
  const totalItemCount = (cart && cart.length > 0)
    ? cart.reduce((acc, item) => acc + item.quantity, 0)
    : 1;

  const orderTimeStr = new Date().toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'short',
    year: 'numeric'
  }) + ' · ' + new Date().toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true
  });

  const whatsappButtonHtml = (type === 'WhatsApp' && whatsappUrl) ? `
    <a href="${whatsappUrl}" class="btn btn-whatsapp btn-block" style="min-height: 50px;">
      <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor"><path d="M12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21 5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.816 9.816 0 0 0 12.04 2zm5.8 14.16c-.24.68-1.4 1.25-1.92 1.33-.5.08-1.15.11-3.72-.94-3.28-1.34-5.4-4.66-5.56-4.88-.16-.22-1.33-1.77-1.33-3.38 0-1.61.84-2.4 1.14-2.73.3-.33.65-.41.87-.41.22 0 .43 0 .62.01.2.01.47-.08.73.55.27.65.92 2.24 1 2.4.08.16.14.36.03.57-.11.22-.16.36-.32.55-.16.19-.34.42-.49.57-.16.16-.33.34-.14.67.19.33.84 1.39 1.8 2.25 1.24 1.1 2.28 1.45 2.61 1.61.33.16.52.14.71-.08.2-.22.84-.98 1.06-1.32.22-.34.45-.28.75-.17.3.11 1.91.9 2.24 1.06.33.16.55.24.63.38.08.14.08.82-.16 1.5z"/></svg>
      <span>Open WhatsApp Order Chat</span>
    </a>
  ` : '';

  const itemsHtml = (cart && cart.length > 0) ? `
    <div class="invoice-items-section">
      <div class="invoice-items-title">Ordered Timepieces (${totalItemCount} item${totalItemCount > 1 ? 's' : ''})</div>
      <div class="invoice-items-list">
        ${cart.map(item => `
          <div class="invoice-item-row">
            <div class="invoice-item-left">
              <img src="${item.image}" alt="${escapeHtml(item.name)}" class="invoice-item-thumb" />
              <div style="min-width: 0;">
                <div class="invoice-item-name">${escapeHtml(item.name)}</div>
                <div class="invoice-item-sub">Qty: ${item.quantity} × ${formatPKR(item.price)}</div>
              </div>
            </div>
            <div class="invoice-item-price">${formatPKR(item.price * item.quantity)}</div>
          </div>
        `).join('')}
      </div>
    </div>
  ` : '';

  const modalHtml = `
    <div id="order-success-modal" class="modal-overlay open" role="dialog" aria-modal="true" aria-labelledby="invoice-title">
      <div class="modal-container order-success-dialog">
        <!-- Close (X) Button -->
        <button type="button" class="modal-close-btn" onclick="document.getElementById('order-success-modal')?.remove()" aria-label="Close invoice popup">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
        </button>

        <!-- Header -->
        <div class="order-success-header">
          <div class="order-success-icon-badge">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><polyline points="20 6 9 17 4 12"></polyline></svg>
          </div>
          <span class="order-success-badge-text">Order Confirmed & Logged</span>
          <h2 id="invoice-title" class="order-success-title">
            Thank You, ${escapeHtml(customer.name)}
          </h2>
          <p class="order-success-subtext">
            Your timepiece has been scheduled for dispatch via TCS Courier from our Lahore horological facility.
          </p>
        </div>

        <!-- Official Horological Invoice Card -->
        <div class="order-invoice-card" id="printable-order-invoice">
          <!-- Top Strip -->
          <div class="invoice-top-strip">
            <div class="invoice-brand">
              ST <span>WATCHES</span>
              <small style="font-size: 0.7rem; color: #65635C; font-weight: 600; margin-left: 6px; text-transform: uppercase;">Official Invoice</small>
            </div>
            <div class="invoice-order-id-badge">#${orderId}</div>
          </div>

          <!-- Customer & Dispatch Coordinates -->
          <div class="invoice-meta-grid">
            <div class="invoice-meta-item">
              <span class="invoice-meta-label">Recipient</span>
              <span class="invoice-meta-val">${escapeHtml(customer.name)}</span>
            </div>
            <div class="invoice-meta-item">
              <span class="invoice-meta-label">Courier Contact</span>
              <span class="invoice-meta-val">${escapeHtml(customer.phone)}</span>
            </div>
            <div class="invoice-meta-item">
              <span class="invoice-meta-label">Delivery City</span>
              <span class="invoice-meta-val">${escapeHtml(customer.city)}</span>
            </div>
            <div class="invoice-meta-item">
              <span class="invoice-meta-label">Payment Mode</span>
              <span class="invoice-meta-val" style="color: #166534;">${type === 'WhatsApp' ? 'WhatsApp Order (COD)' : 'Cash on Delivery (COD)'}</span>
            </div>
            <div class="invoice-meta-item full-width">
              <span class="invoice-meta-label">Street Address</span>
              <span class="invoice-meta-val">${escapeHtml(customer.address)}</span>
            </div>
            ${(customer.notes && customer.notes !== 'None') ? `
              <div class="invoice-meta-item full-width">
                <span class="invoice-meta-label">Courier Instructions</span>
                <span class="invoice-meta-val" style="font-style: italic; color: #65635C;">${escapeHtml(customer.notes)}</span>
              </div>
            ` : ''}
            <div class="invoice-meta-item full-width">
              <span class="invoice-meta-label">Order Date & Timestamp</span>
              <span class="invoice-meta-val" style="font-size: 0.78rem; color: #65635C;">${orderTimeStr}</span>
            </div>
          </div>

          <!-- Ordered Items Breakdown -->
          ${itemsHtml}

          <!-- Financial Calculation Rows -->
          <div class="invoice-calc-row">
            <span>Subtotal</span>
            <strong style="color: #0B0B0B; font-variant-numeric: tabular-nums;">${formatPKR(subtotal)}</strong>
          </div>
          <div class="invoice-calc-row">
            <span>Express Delivery (TCS)</span>
            <strong style="font-variant-numeric: tabular-nums; color: ${isFreeDelivery ? '#15803D' : '#0B0B0B'};">${isFreeDelivery ? 'FREE (Complimentary)' : formatPKR(delivery)}</strong>
          </div>
          <div class="invoice-calc-row total">
            <span>Grand Total Payable</span>
            <span class="invoice-total-amount">${formatPKR(total)}</span>
          </div>

          <!-- Dispatch Guarantee Notice -->
          <div class="invoice-dispatch-note">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
            <div>
              <strong>Open-Box Inspection Enabled:</strong> Inspect and verify the timepiece upon doorstep delivery before paying. A tracking number will be SMS-dispatched to <strong>${escapeHtml(customer.phone)}</strong>.
            </div>
          </div>
        </div>

        <!-- Action Buttons -->
        <div class="invoice-actions-group">
          ${whatsappButtonHtml}

          <div class="invoice-secondary-btns">
            <button type="button" class="btn btn-outline-dark btn-download-invoice" id="btn-download-invoice" style="min-height: 48px;">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
              <span>Download Invoice</span>
            </button>

            <a href="shop.html" class="btn btn-dark" style="min-height: 48px;">
              <span>Continue Shopping</span>
            </a>
          </div>

          <a href="index.html" style="display: block; text-align: center; font-size: 0.82rem; color: #65635C; padding: 0.4rem 0; text-decoration: underline;">
            Return to ST Watches Homepage
          </a>
        </div>
      </div>
    </div>
  `;

  document.body.insertAdjacentHTML('beforeend', modalHtml);

  // Attach Download Invoice Handler
  const downloadBtn = document.getElementById('btn-download-invoice');
  if (downloadBtn) {
    downloadBtn.addEventListener('click', (e) => {
      e.preventDefault();
      downloadOrderInvoice(orderId, customer, cart, total, type);
    });
  }
}

/**
 * Downloads the Official Horological Invoice
 * Uses jsPDF when available for direct PDF file generation;
 * Falls back gracefully to a responsive, standalone HTML invoice file download.
 */
function downloadOrderInvoice(orderId, customer, cart, total, type) {
  try {
    const subtotal = (cart && cart.length > 0)
      ? cart.reduce((acc, item) => acc + (item.price * item.quantity), 0)
      : total;
    const delivery = Math.max(0, total - subtotal);
    const isFreeDelivery = delivery <= 0;
    const dateStr = new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
    const timeStr = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });

    // Try jsPDF for instant .pdf download
    const jspdfLib = window.jspdf ? window.jspdf.jsPDF : null;
    if (jspdfLib) {
      const doc = new jspdfLib({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });

      const margin = 16;
      let y = 18;

      // Header Bar
      doc.setFillColor(11, 11, 11);
      doc.rect(0, 0, 210, 24, 'F');

      doc.setTextColor(255, 255, 255);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(15);
      doc.text('ST WATCHES', margin, 15);

      doc.setTextColor(201, 162, 39);
      doc.setFontSize(10);
      doc.text('PAKISTAN', margin + 44, 15);

      doc.setTextColor(220, 220, 220);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8.5);
      doc.text('OFFICIAL HOROLOGICAL INVOICE', 210 - margin, 15, { align: 'right' });

      y = 34;

      // Order Reference & Date
      doc.setTextColor(11, 11, 11);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(13);
      doc.text(`Invoice #${orderId}`, margin, y);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8.5);
      doc.setTextColor(110, 110, 110);
      doc.text(`Issued: ${dateStr} · ${timeStr}`, 210 - margin, y, { align: 'right' });

      y += 6;
      doc.setDrawColor(220, 220, 220);
      doc.setLineWidth(0.3);
      doc.line(margin, y, 210 - margin, y);
      y += 6;

      // Recipient Coordinates Card
      doc.setFillColor(250, 249, 246);
      doc.rect(margin, y, 210 - (margin * 2), 34, 'F');
      doc.setDrawColor(225, 223, 216);
      doc.rect(margin, y, 210 - (margin * 2), 34, 'S');

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8);
      doc.setTextColor(160, 125, 20);
      doc.text('DISPATCH & RECIPIENT DETAILS', margin + 4, y + 5.5);

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9);
      doc.setTextColor(20, 20, 20);
      doc.text(`Recipient: ${customer.name}`, margin + 4, y + 12);
      doc.text(`Contact: ${customer.phone}`, margin + 4, y + 18);

      doc.text(`City: ${customer.city}`, 115, y + 12);
      doc.text(`Payment: ${type === 'WhatsApp' ? 'WhatsApp Order (COD)' : 'Cash on Delivery (COD)'}`, 115, y + 18);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8.5);
      doc.setTextColor(80, 80, 80);
      const addressLines = doc.splitTextToSize(`Address: ${customer.address}`, 210 - (margin * 2) - 8);
      doc.text(addressLines, margin + 4, y + 25);

      y += 40;

      // Items Table Header
      doc.setFillColor(11, 11, 11);
      doc.rect(margin, y, 210 - (margin * 2), 7.5, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8);
      doc.text('TIMEPIECE ITEM', margin + 4, y + 5);
      doc.text('QTY', 125, y + 5, { align: 'center' });
      doc.text('UNIT PRICE', 158, y + 5, { align: 'right' });
      doc.text('TOTAL', 210 - margin - 4, y + 5, { align: 'right' });

      y += 7.5;

      // Items List
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(20, 20, 20);
      doc.setFontSize(8.5);

      if (cart && cart.length > 0) {
        cart.forEach((item, index) => {
          if (index % 2 === 1) {
            doc.setFillColor(250, 250, 250);
            doc.rect(margin, y, 210 - (margin * 2), 8.5, 'F');
          }
          doc.text(item.name.substring(0, 48), margin + 4, y + 5.5);
          doc.text(String(item.quantity), 125, y + 5.5, { align: 'center' });
          doc.text(formatPKR(item.price), 158, y + 5.5, { align: 'right' });
          doc.text(formatPKR(item.price * item.quantity), 210 - margin - 4, y + 5.5, { align: 'right' });
          y += 8.5;
        });
      }

      doc.setDrawColor(220, 220, 220);
      doc.line(margin, y, 210 - margin, y);
      y += 6;

      // Calculations
      doc.setFontSize(8.5);
      doc.setTextColor(80, 80, 80);
      doc.text('Subtotal:', 140, y);
      doc.setTextColor(20, 20, 20);
      doc.text(formatPKR(subtotal), 210 - margin - 4, y, { align: 'right' });
      y += 5.5;

      doc.setTextColor(80, 80, 80);
      doc.text('Express Courier (TCS):', 140, y);
      doc.setTextColor(isFreeDelivery ? 22 : 20, isFreeDelivery ? 128 : 20, isFreeDelivery ? 61 : 20);
      doc.text(isFreeDelivery ? 'FREE (Complimentary)' : formatPKR(delivery), 210 - margin - 4, y, { align: 'right' });
      y += 6.5;

      doc.setDrawColor(201, 162, 39);
      doc.setLineWidth(0.4);
      doc.line(135, y, 210 - margin, y);
      y += 6.5;

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10.5);
      doc.setTextColor(11, 11, 11);
      doc.text('Grand Total Payable:', 140, y);
      doc.setTextColor(170, 130, 20);
      doc.text(formatPKR(total), 210 - margin - 4, y, { align: 'right' });
      y += 12;

      // Trust Strip
      doc.setFillColor(240, 253, 244);
      doc.rect(margin, y, 210 - (margin * 2), 15, 'F');
      doc.setDrawColor(187, 247, 208);
      doc.rect(margin, y, 210 - (margin * 2), 15, 'S');
      doc.setTextColor(22, 101, 52);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8.5);
      doc.text('100% Risk-Free Cash on Delivery & Open-Box Inspection Enabled', margin + 4, y + 5.5);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.5);
      doc.text('Dispatched securely via TCS Courier across Pakistan. Inspect the package before paying the courier rider.', margin + 4, y + 10.5);

      // Footer
      doc.setFontSize(7.5);
      doc.setTextColor(120, 120, 120);
      doc.text('ST Watches Pakistan · Flagship Lahore · WhatsApp Orders: +92 300 1234567 · orders@stwatches.pk', 105, 285, { align: 'center' });

      doc.save(`ST-Watches-Invoice-${orderId}.pdf`);
      showToast('Invoice PDF downloaded successfully!', 'success');
      return;
    }

    // Fallback: Standalone Responsive HTML Invoice File Download
    downloadHtmlInvoice(orderId, customer, cart, total, type, subtotal, delivery, isFreeDelivery, dateStr, timeStr);
  } catch (err) {
    console.error('Invoice download error, using HTML invoice download fallback:', err);
    const subtotal = (cart && cart.length > 0)
      ? cart.reduce((acc, item) => acc + (item.price * item.quantity), 0)
      : total;
    const delivery = Math.max(0, total - subtotal);
    const isFreeDelivery = delivery <= 0;
    const dateStr = new Date().toLocaleDateString('en-GB');
    const timeStr = new Date().toLocaleTimeString('en-US');
    downloadHtmlInvoice(orderId, customer, cart, total, type, subtotal, delivery, isFreeDelivery, dateStr, timeStr);
  }
}

function downloadHtmlInvoice(orderId, customer, cart, total, type, subtotal, delivery, isFreeDelivery, dateStr, timeStr) {
  const itemsRows = (cart && cart.length > 0) ? cart.map(i => `
    <tr>
      <td style="padding: 10px 8px; border-bottom: 1px solid #E5E3DC; font-weight: 600;">${escapeHtml(i.name)}</td>
      <td style="padding: 10px 8px; border-bottom: 1px solid #E5E3DC; text-align: center;">${i.quantity}</td>
      <td style="padding: 10px 8px; border-bottom: 1px solid #E5E3DC; text-align: right;">${formatPKR(i.price)}</td>
      <td style="padding: 10px 8px; border-bottom: 1px solid #E5E3DC; text-align: right; font-weight: 600;">${formatPKR(i.price * i.quantity)}</td>
    </tr>
  `).join('') : `
    <tr>
      <td colspan="4" style="padding: 12px; text-align: center;">ST Watches Luxury Timepiece</td>
    </tr>
  `;

  const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ST Watches Official Invoice - #${orderId}</title>
  <style>
    * { box-sizing: border-box; }
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; margin: 0; padding: 24px 16px; background: #F8F7F4; color: #111; }
    .invoice-container { max-width: 650px; margin: 0 auto; background: #FFFFFF; border: 1px solid #E5E3DC; border-radius: 8px; padding: 28px; box-shadow: 0 4px 20px rgba(0,0,0,0.06); }
    .invoice-header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #C9A227; padding-bottom: 16px; margin-bottom: 20px; }
    .brand-title { font-size: 22px; font-weight: 700; letter-spacing: 0.05em; color: #0B0B0B; }
    .brand-title span { color: #C9A227; }
    .invoice-id-pill { background: #FAFAFA; border: 1px solid #E5E3DC; padding: 4px 10px; border-radius: 4px; font-family: monospace; font-weight: 700; font-size: 14px; }
    .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; background: #FAFAFA; border: 1px solid #E5E3DC; padding: 14px; border-radius: 6px; margin-bottom: 20px; font-size: 13px; }
    .info-col-full { grid-column: 1 / -1; }
    .info-label { font-size: 11px; text-transform: uppercase; color: #777; font-weight: 600; margin-bottom: 2px; }
    .info-val { font-weight: 600; color: #111; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 13px; }
    th { text-align: left; padding: 10px 8px; border-bottom: 2px solid #111; font-size: 11px; text-transform: uppercase; letter-spacing: 0.05em; }
    .totals-box { margin-left: auto; width: 280px; font-size: 14px; }
    .calc-line { display: flex; justify-content: space-between; margin-bottom: 8px; color: #666; }
    .calc-line.grand { font-size: 16px; font-weight: 700; color: #0B0B0B; border-top: 1px solid #E5E3DC; padding-top: 10px; margin-top: 10px; }
    .grand-amount { color: #C9A227; }
    .dispatch-badge { background: #F0FDF4; border: 1px solid #BBF7D0; color: #166534; padding: 12px; border-radius: 6px; font-size: 12px; line-height: 1.4; margin-top: 20px; }
    .footer-note { text-align: center; font-size: 11px; color: #888; margin-top: 24px; padding-top: 16px; border-top: 1px solid #E5E3DC; }
    @media print { body { background: #FFF; padding: 0; } .invoice-container { box-shadow: none; border: none; padding: 0; } }
  </style>
</head>
<body>
  <div class="invoice-container">
    <div class="invoice-header">
      <div>
        <div class="brand-title">ST <span>WATCHES</span></div>
        <div style="font-size: 12px; color: #666; margin-top: 2px;">Official Horological Invoice</div>
      </div>
      <div class="invoice-id-pill">#${orderId}</div>
    </div>
    <div class="info-grid">
      <div><div class="info-label">Recipient</div><div class="info-val">${escapeHtml(customer.name)}</div></div>
      <div><div class="info-label">Courier Phone</div><div class="info-val">${escapeHtml(customer.phone)}</div></div>
      <div><div class="info-label">Delivery City</div><div class="info-val">${escapeHtml(customer.city)}</div></div>
      <div><div class="info-label">Payment Mode</div><div class="info-val">${type === 'WhatsApp' ? 'WhatsApp Order (COD)' : 'Cash on Delivery (COD)'}</div></div>
      <div class="info-col-full"><div class="info-label">Street Address</div><div class="info-val">${escapeHtml(customer.address)}</div></div>
      <div class="info-col-full"><div class="info-label">Date & Timestamp</div><div class="info-val">${dateStr} · ${timeStr}</div></div>
    </div>
    <table>
      <thead>
        <tr>
          <th>Timepiece</th>
          <th style="text-align: center;">Qty</th>
          <th style="text-align: right;">Unit Price</th>
          <th style="text-align: right;">Total</th>
        </tr>
      </thead>
      <tbody>
        ${itemsRows}
      </tbody>
    </table>
    <div class="totals-box">
      <div class="calc-line"><span>Subtotal:</span><span>${formatPKR(subtotal)}</span></div>
      <div class="calc-line"><span>Express Delivery (TCS):</span><span style="color: ${isFreeDelivery ? '#15803D' : '#111'}; font-weight: 600;">${isFreeDelivery ? 'FREE (Complimentary)' : formatPKR(delivery)}</span></div>
      <div class="calc-line grand"><span>Total Payable:</span><span class="grand-amount">${formatPKR(total)}</span></div>
    </div>
    <div class="dispatch-badge">
      🔒 <strong>Open-Box Doorstep Verification:</strong> Pay cash to the courier rider upon delivery after verifying the package.
    </div>
    <div class="footer-note">
      ST Watches Pakistan · Flagship Lahore Facility · WhatsApp Orders: +92 300 1234567 · orders@stwatches.pk
    </div>
  </div>
</body>
</html>`;

  const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `ST-Watches-Invoice-${orderId}.html`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  showToast('Invoice downloaded successfully!', 'success');
}
